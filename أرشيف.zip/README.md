#adtnim

Add a welcome message when the phone is turned on

